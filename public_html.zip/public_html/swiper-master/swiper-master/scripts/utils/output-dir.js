export const outputDir = 'dist';
