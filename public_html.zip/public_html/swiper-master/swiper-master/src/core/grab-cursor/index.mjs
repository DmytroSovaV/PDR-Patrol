import setGrabCursor from './setGrabCursor.mjs';
import unsetGrabCursor from './unsetGrabCursor.mjs';

export default {
  setGrabCursor,
  unsetGrabCursor,
};
