import setTransition from './setTransition.mjs';
import transitionStart from './transitionStart.mjs';
import transitionEnd from './transitionEnd.mjs';

export default {
  setTransition,
  transitionStart,
  transitionEnd,
};
