<?php
return [
    'email_user' => 'mail@pdrpatrol.ca', 
    'email_pass' => 'M@il123456',         
    'email_to'   => 'oleksandrkryshtopa@gmail.com'
];