<?php
return [
    'email_user' => 'mail@pdrpatrol.ca', /// Mail 
    'email_pass' => 'M@il123456' // password 16 symbols
];